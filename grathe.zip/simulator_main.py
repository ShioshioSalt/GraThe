import sumolib
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import matplotlib.animation as animation
import sys
import copy
import os
import csv


a = 202
#a = int(sys.argv[1])
print("seed値 : " + str(a))
np.random.seed(a)

# Read the network
network = sumolib.net.readNet("grid5x5.net.xml")
road_filename = "5x5" 
G = nx.DiGraph()

num_points = 600
num_obstacles = 10
num_fakecar = 1
num_fakeobstacles = 1


diff_dist = 50


fig, ax = plt.subplots()
dots, = ax.plot([], [], 'go', markersize=5)
fdots, = ax.plot([], [], "mo", markersize = 5)
obstacles, = ax.plot([], [], 'rD', markersize=3)
fobstacles, = ax.plot([], [], "cD", markersize = 3)
ax.axis('off')

points_list = []
fakecar_list = []
allcar_list = []
obstacle_list = []
obstacle_positions = []
fake_obstacle_positions = []
used_edges = []
total_obstacle_list = []
fake_obstacle_list = []

node_list = []
edge_list = []
point_edge = {}

point_current_locations = []

node_queues = {}

arrival_times = []

total_distances_list = []


class Point:
    def __init__(self, G, i):
        self.G = copy.deepcopy(G)
        self.number = i
        self.encountered_obstacles = []
        self.encountered_obstacles_edges = []
        self.fake_edge_list = []
        #print(self.G.nodes)
        self.current_node = np.random.choice(list(self.G.nodes()))
        self.target_node = np.random.choice(list(self.G.nodes()))

        if self.current_node not in node_queues:
            node_queues[self.current_node] = []
        node_queues[self.current_node].append(self)

        while self.current_node == self.target_node:
            self.target_node = np.random.choice(list(self.G.nodes()))

        self.path = nx.astar_path(self.G, self.current_node, self.target_node, heuristic=None)
        #print(self.path)
        self.current_pos = np.array(self.G.nodes[self.current_node]['pos'])
        self.next_node_index = 1
        #self.current_edge = (self.current_node, self.path[self.next_node_index])
        self.next_node = self.path[1] if len(self.path) > 1 else None
        self.current_edge = (self.current_node, self.next_node) if self.next_node else None
        point_edge[self.current_edge].append(self)
        self.target_pos = np.array(self.G.nodes[self.next_node]['pos']) if self.next_node else self.current_pos
        #self.target_pos = np.array(self.G.nodes[self.path[self.next_node_index]]['pos'])
        self.max_speed = 6
        self.speed = 0
        self.ready_to_move = False 
        

        self.total_distance_traveled = 0


    def walk(self):
        #print(self, self.current_node, self.next_node, self.target_node)
        if self.ready_to_move:  # ready_to_moveがTrueである場合のみ動かす
            current_queue = node_queues.get(self.current_node, [None])
            if current_queue and current_queue[0] == self:
                node_queues[self.current_node].pop(0)

            direction = self.target_pos - self.current_pos
            norm = np.linalg.norm(direction)

            if self in point_edge[self.current_edge]:
                point_edge[self.current_edge].remove(self)

            #print("Current Node first:", self.current_node)
            #print("Target Node: first", self.target_node)
            #print("Path:first", self.path)
            inter_car_distance = 0

            nearest_object = None
            min_distance = float('inf')

            if len(point_edge) >= 1 :
                inter_car_distance = diff_dist

            else:
                for other_object in point_edge[self.current_edge]:
                    #print("for文")
                    if other_object != self:  # 自分自身でないことを確認
                        # 他のオブジェクトとの距離を計算
                        distance_to_other_object = np.linalg.norm(self.current_pos - other_object.position)

                        # 最も近いオブジェクトを更新
                        if distance_to_other_object < min_distance:
                            min_distance = distance_to_other_object #自分から何かしらのobj(car or obs)の最小距離
                            nearest_object = other_object #自分から一番近いobj

                        if diff_dist > min_distance : #視界距離よりも最小距離のほうが小さい場合
                            inter_car_distance = min_distance

                        else:
                            inter_car_distance = diff_dist

            self.speed = 0.5*self.max_speed*(np.tanh(inter_car_distance-2) + np.tanh(2))
            #print(self.speed)

            if norm > 0:
                step = self.speed * direction / norm
                self.current_pos += step

            self.exchange_info_with_nearby_points(point_edge[(self.current_node),(self.next_node)])
            self.exchange_info_with_nearby_points(point_edge[(self.next_node),(self.current_node)])

            for obstacle in obstacle_list:
                if obstacle.edge[:2] == self.current_edge:
                    if np.linalg.norm(obstacle.position - self.current_pos) < self.speed:
                        self.encountered_obstacles_edges.append(self.current_edge)
                        if not hasattr(self, 'original_target_node'):
                            self.original_target_node = self.target_node

            # 逆方向のエッジが存在するかを確認
                        self.Uturn()
                # ここで break すると、Uターン処理が完了せずに次のイテレーションへ進む可能性があるため、break は使用しない

            # 移動処理
            if np.linalg.norm(self.target_pos - self.current_pos) < self.speed:
                self.current_pos = self.target_pos
                self.current_node = self.next_node
            # 新しい経路の計算
                if self.current_node != self.target_node:
                    self.path_recalculation()
                else:
                    return True

            point_edge[self.current_edge].append(self)

            # 今回のステップで移動した距離を計算
            distance_moved = np.linalg.norm(step)
            # 合計の移動距離を増やす
            self.total_distance_traveled += distance_moved

            return False

    
    def update_current_edge(self):
        if self.next_node_index < len(self.path):
            self.current_edge = (self.path[self.next_node_index - 1], self.path[self.next_node_index])
            
        else:
            self.current_edge = None


    def exchange_info_with_nearby_points(self, current_edge_list):
        for other_point in current_edge_list:
            if other_point.number > self.number:
                continue  # インデックスが自分より大きいポイントは無視

            distance = np.linalg.norm(self.current_pos - other_point.current_pos)
            if distance <= 5:  # ノルムが5以下の場合
                # 障害物情報の交換
                #print(self.encountered_obstacles_edges, other_point.encountered_obstacles_edges, other_point.fake_edge_list)
                self.encountered_obstacles_edges = list(set(self.encountered_obstacles_edges + other_point.encountered_obstacles_edges + other_point.fake_edge_list) - set(self.fake_edge_list))
                other_point.encountered_obstacles_edges = list(set(other_point.encountered_obstacles_edges + self.encountered_obstacles_edges + self.fake_edge_list) - set(other_point.fake_edge_list))

    def path_recalculation(self):
        for edge in self.encountered_obstacles_edges:
            if self.G.has_edge(*edge):
                self.G.remove_edge(*edge)
        self.path = nx.astar_path(self.G, self.current_node, self.target_node, heuristic=None)
        self.next_node_index = 1
        self.next_node = self.path[self.next_node_index] if len(self.path) > 1 else None
        self.target_pos = np.array(self.G.nodes[self.next_node]['pos']) if self.next_node else self.current_pos
        if self in point_edge[self.current_edge]:
            point_edge[self.current_edge].remove(self)
        self.current_edge = ((self.current_node),(self.next_node))

    def Uturn(self):
        if self.G.has_edge(self.current_edge[1], self.current_edge[0]):
                # Uターンを開始
            self.current_node, self.next_node = self.next_node, self.current_node  # ノードを交換
            self.current_edge = (self.current_edge[1], self.current_edge[0])  # エッジを反転
            self.target_pos = np.array(self.G.nodes[self.next_node]['pos'])
    
    def get_total_distance_traveled(self):
        return self.total_distance_traveled
    
class FakeCar(Point):
    def __init__(self, G, i):
        super().__init__(G, i)
        self.fake_obstacle_list = []

        # FakeCarに固有の初期化コードをここに追加できる

    def create_fake_obstacles(self, num_fakeobstacles):
        global total_obstacle_list, used_edges
        all_edges = list(self.G.edges(data=True))
        for _ in range(num_fakeobstacles):
            while True:
                random_index = np.random.randint(0, len(all_edges))
                random_edge = all_edges[random_index]
                if random_edge not in used_edges:
                    obstacle = FakeObstacle(random_edge)
                    total_obstacle_list.append(obstacle)
                    self.fake_obstacle_list.append(obstacle)
                    self.fake_edge_list.append(random_edge[:2])
                    used_edges.append(random_edge)
                    fake_obstacle_positions.append(random_edge[2]['pos'])
                    break



class Obstacle:
    def __init__(self, edge):
        self.edge = edge
        self.position = edge[2]['pos'] 

class FakeObstacle(Obstacle):
    def __init__(self, edge):
        super().__init__(edge)


# Create the network graph
for node in network.getNodes():
    node_pos = node.getCoord()
    node_id = node.getID()
    node_list.append({'id': node_id, 'pos': (node_pos[0], node_pos[1])})
    G.add_node(node_id, pos=(node_pos[0], node_pos[1]))

for edge in network.getEdges():
    src_node = edge.getFromNode()
    dest_node = edge.getToNode()
    src_id = src_node.getID()
    dest_id = dest_node.getID()
    edge_id = edge.getID()
    edge_list.append({'id': edge_id, 'src': src_id, 'dest': dest_id})
    src_pos = np.array(src_node.getCoord())
    dest_pos = np.array(dest_node.getCoord())
    G.add_edge(src_id, dest_id, pos=dest_pos - 0.01 * (dest_pos - src_pos))

point_edge = {(edge["src"], edge["dest"]): [] for edge in edge_list}

# Create points
for i in range(num_points):
    point = Point(G,i)
    points_list.append(point)
    allcar_list.append(point)

for i in range(num_fakecar):
    fakecar = FakeCar(G,i)
    fakecar_list.append(fakecar)
    allcar_list.append(fakecar)

for _ in fakecar_list:
    _.create_fake_obstacles(num_fakeobstacles)

print(used_edges)

# Place obstacles
all_edges = list(G.edges(data=True))
for _ in range(num_obstacles):
    while True:
        random_index = np.random.randint(0, len(all_edges))
        random_edge = all_edges[random_index]
        print(random_edge, used_edges)
        #if random_edge not in used_edges:
        if not any(random_edge[:2] == edge[:2] for edge in used_edges):
            obstacle = Obstacle(random_edge)
            total_obstacle_list.append(obstacle)
            obstacle_list.append(obstacle)
            used_edges.append(random_edge)
            obstacle_positions.append(random_edge[2]['pos'])
            break


#グラフの接続テスト
updated_G = G.copy()

#all_edges = list(updated_G.edges())
#print(all_edges)

#print(used_edges)
#for obstacle_pos in obstacle_positions:
    # 障害物が影響を与えるエッジを特定
    #affected_edges = [(u, v) for u, v, data in G.edges(data=True) if np.allclose(data['pos'], obstacle_pos)]
    #affected_edges = used_edges
    #for edge in affected_edges:
        #node_pair = edge[:2]  # タプルやリストの最初の2要素を取り出す
        #print(node_pair)
    # 影響を受けるエッジを無効にする
for u, v, _ in used_edges:
        #print(u,v,_)
        #print(updated_G.edges)
    updated_G.remove_edge(u,v)
if nx.is_strongly_connected(updated_G) == True:  
    print("接続テスト完了")
    pass
else:
    print("到達できないnodeがあります")
    sys.exit()



def init():
    node_positions = nx.get_node_attributes(G, 'pos')
    nx.draw(G, node_positions, node_size=5, node_color='blue', ax=ax, arrowstyle=None, arrows=False)
    dots.set_data([], [])
    obstacles.set_data([], [])
    return dots, obstacles

def update(num):
    print(num)
    #for sublist in point_edge:
        #sublist.clear()
    xdata = []
    ydata = []
    fxdata = []
    fydata = []
    
    # 各フレームで一台だけキューから出てくるようにする
    for node, queue in node_queues.items():
        if queue:
            queue[0].ready_to_move = True

    points_to_remove = []
    point_current_locations.clear()

    for point in allcar_list:
        reached = point.walk()
        point.update_current_edge()

        if not reached:
            x, y = point.current_pos
            #print(type(point))
            #if isinstance(point, Point):   この書式はサブクラスも巻き込む、FakeCarからやると可能
            if type(point) is Point:
                xdata.append(x)
                ydata.append(y)
                #print(str("po"),x,y)
            elif type(point) is FakeCar:
                fxdata.append(x)
                fydata.append(y)
                #print(str("fc"),x,y)
            point_current_locations.append({
                'point': point,
                'current_node': point.current_node,
                'current_edge': point.current_edge,
            })
        else:
            points_to_remove.append(point)
            # numは現在のフレーム数など、適切な時間情報を取得する方法に置き換えてください
            arrival_time = num  
            arrival_times.append(arrival_time)
            #各車両の移動距離を保存するリスト
            total_distance = point.get_total_distance_traveled()
            total_distances_list.append((total_distance))
            #total_result = list(zip(arrival_times, total_distances_list ))
            #print(total_result) 

    for point in points_to_remove:
        allcar_list.remove(point)

    dots.set_data(xdata, ydata)
    fdots.set_data(fxdata, fydata)

    if len(allcar_list) == 0:
        print("All vehicles have reached their destinations.")
        #print("Arrival times:", arrival_times)
        #print("total Distance" , total_distances_list)
        #print("Total simulation step: " + str(num - 1))  #シミュレータのステップ数


        plt.clf()
        # 総移動距離のヒストグラムを保存
        plt.hist(total_distances_list, bins=50, rwidth=0.9, color='b')  
        plt.xlabel("moving dictance")  
        plt.ylabel("num car")

        # 保存先の相対パス
        histogram_folder = "moving_distance_hist"
        histogram_filename = f"総移動距離({a}) {road_filename} {num_points} {num_obstacles}fake_car{num_fakecar} seed{a}origin.png" #{num_fake_points} １両あたりが保持する偽障害物({having_fake_obstacle})seed{a}.png"
        save_path_name = os.path.join(histogram_folder, histogram_filename)

        # ヒストグラムを保存
        plt.savefig(save_path_name)
        plt.clf()

        # ゴールタイムのヒストグラムを保存
        plt.hist(arrival_times, bins=50, rwidth=0.9, color='b')  
        plt.xlabel("goal time")  
        plt.ylabel("num car")

        # 保存先の相対パス
        histogram_folder2 = "goal_time_hist"
        histogram_filename2 = f"ゴールタイム({a}) {road_filename} {num_points} {num_obstacles}fake_car{num_fakecar}seed{a}origin.png"   #{num_fake_points} {having_fake_obstacle}seed{a}.png"
        save_path_name2 = os.path.join(histogram_folder2, histogram_filename2)

        # ヒストグラムを保存
        plt.savefig(save_path_name2)
        plt.clf()

        plt.close(fig)

        # CSVファイルに経過時間を書き込み保存
        save_to_csv("arrival_times.csv", arrival_times, total_distances_list)  # total_distances_list を追加

    obstacle_xdata = [obs[0] for obs in obstacle_positions]
    obstacle_ydata = [obs[1] for obs in obstacle_positions]
    obstacles.set_data(obstacle_xdata, obstacle_ydata)

    obstacle_fxdata = [obs[0] for obs in fake_obstacle_positions]
    obstacle_fydata = [obs[1] for obs in fake_obstacle_positions]
    fobstacles.set_data(obstacle_fxdata, obstacle_fydata)


    return dots, fdots, obstacles, fobstacles

# CSVファイルにデータを書き込む関数
def save_to_csv(filename, arrival_times, total_distances_list):
    # カレントディレクトリを取得
    current_directory = os.getcwd()
    # 保存先の相対パス
    relative_path = "result(csv)"
    # 保存フォルダの絶対パスを作成
    save_folder = os.path.join(current_directory, relative_path)
    os.makedirs(save_folder, exist_ok=True) #ディレクトリがない場合作成

    filename = f"result {road_filename} {num_points} {num_obstacles} fake_car{num_fakecar}seed{a}origin"

    with open(os.path.join(save_folder, filename), mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Car Index", "Arrival Time", "Total Distance"])  # ヘッダー行を追加（適宜変更）
        print("csvへの書き込み中")

        for i, (arrival_time, moving_distance) in enumerate(zip(arrival_times, total_distances_list)):
            writer.writerow([i + 1, arrival_time, moving_distance])  # 車両のインデックス、到着時刻、移動距離を別々の列に書き込む


ani = animation.FuncAnimation(fig, update, init_func=init, blit=True, interval=20, repeat=False, cache_frame_data=False)

plt.show()